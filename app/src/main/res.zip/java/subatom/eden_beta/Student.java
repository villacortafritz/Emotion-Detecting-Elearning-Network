package subatom.eden_beta;

/**
 * Created by JSP on 11/27/2017.
 */

public class Student {
    public String id;
    public String name;
    public int age;
    public boolean excel;
    public String gender;

    public Student(String id, String name, int age, String gender, boolean excel) {
        this.id = id;
        this.name = name;
        this.age = age;
        this.gender = gender;
        this.excel = excel;
    }

}
