package subatom.eden_beta;

import android.app.Activity;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Handler;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.transition.Explode;

public class secondinstructions extends Activity {

    private static int SPLASH_TIME_OUT = 8000;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_secondinstructions);

        new Handler().postDelayed(new Runnable() {
            @Override
            public void run() {
                Explode explode = new Explode();
                getWindow().setExitTransition(explode);

                SharedPreferences preferences = getPreferences(MODE_PRIVATE);
                boolean ranBefore = preferences.getBoolean("RanBefore", false);

                Intent i = new Intent(secondinstructions.this, thirdinstructions.class);
                startActivity(i);

            }
        }, SPLASH_TIME_OUT);
    }
}
